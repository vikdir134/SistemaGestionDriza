import React
  from 'react';

import ReactDOM
  from 'react-dom/client';

import App
  from './App';

import GestionDrizaThemeProvider
  from './theme/GestionDrizaThemeProvider';

import './index.css';
import './styles/pedidos.css';


ReactDOM
  .createRoot(
    document.getElementById(
      'root'
    )!
  )
  .render(
    <React.StrictMode>

      <GestionDrizaThemeProvider>

        <App />

      </GestionDrizaThemeProvider>

    </React.StrictMode>
  );
